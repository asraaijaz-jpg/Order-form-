import React, { useState } from "react";
import "../node_modules/bootstrap/dist/js/bootstrap.bundle";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import PlaceOrder from "./components/PlaceOrder";

function App() {
  return <PlaceOrder />;
}

export default App;
